package com.bank.ebanking.models;

/**
 * @author AkashRastogi
 *
 */
public enum AccountType {

    CHECKING, SAVINGS, MONEY_MARKET
}
