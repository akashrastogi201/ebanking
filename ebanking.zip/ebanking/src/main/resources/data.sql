INSERT INTO customer (id, first_Name, last_Name, address, phone_Number, social_Security_Number) VALUES (1, 'Akash', 'Rastogi', '222 Pimple Saudagar', '7822069528', '063876787');
INSERT INTO customer (id, first_Name, last_Name, address, phone_Number, social_Security_Number) VALUES (2, 'Sumit', 'Jain', '222 Pimple Saudagar', '1234567891', '7937739201');
INSERT INTO customer (id, first_Name, last_Name, address, phone_Number, social_Security_Number) VALUES (3, 'Ankit', 'Sharma', '222 Pimple Saudagar', '2134657812', '8975982378');

INSERT INTO account (id, Account_type, amount, customer_id) VALUES (1, 'SAVINGS', 1000, 1);
INSERT INTO account (id, Account_type, amount, customer_id) VALUES (2, 'CHECKING', 5000, 2);
INSERT INTO account (id, Account_type, amount, customer_id) VALUES (3, 'MONEY_MARKET', 1000, 3);